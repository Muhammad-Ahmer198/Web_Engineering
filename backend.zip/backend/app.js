import dotenv from "dotenv";
dotenv.config({ path: "backend/config/config.env" });

import { v2 as cloudinary } from "cloudinary";   // ← ADD

cloudinary.config({                                // ← ADD
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key:    process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

import express from "express";
import cookieParser from "cookie-parser";
import cors from "cors";
import { connectDatabase } from "./config/dbConnect.js";
import errorMiddleware from "./middlewares/errors.js";
import { ensureUploadDirs, UPLOADS_ROOT } from "./utils/localStorage.js";

ensureUploadDirs();

// Routes
import authRoutes from "./routes/auth.js";
import videoRoutes from "./routes/video.js";
import captionRoutes from "./routes/caption.js";
import translateRoutes from "./routes/translate.js";

process.on("uncaughtException", (err) => {
  console.log(`Error: ${err.message}`);
  process.exit(1);
});

connectDatabase();

const app = express();

app.use(cors({
  origin: "http://localhost:5173",
  credentials: true,
}));
app.use(express.json({ limit: "500mb" }));
app.use(express.urlencoded({ limit: "500mb", extended: true }));
app.use(cookieParser());

// Serves backend/uploads/videos and backend/uploads/burned so locally-saved
// files are watchable immediately, before/without waiting on Cloudinary.
app.use("/uploads", express.static(UPLOADS_ROOT));

app.use("/api/v1", authRoutes);
app.use("/api/v1", videoRoutes);
app.use("/api/v1", captionRoutes);
app.use("/api/v1", translateRoutes);

app.use(errorMiddleware);

const server = app.listen(process.env.PORT, () => {
  console.log(`Server on PORT ${process.env.PORT} in ${process.env.NODE_ENV} mode.`);
});

process.on("unhandledRejection", (err) => {
  console.log(`Error: ${err.message}`);
  server.close(() => process.exit(1));
});