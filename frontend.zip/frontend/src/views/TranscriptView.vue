<script setup>

import { ref } from 'vue'

import TranscriptCard from '../components/transcript/TranscriptCard.vue'

import EmptyState from '../components/transcript/EmptyState.vue'

const transcripts = ref([

{

id:1,

filename:'Meeting.mp3',

language:'English',

duration:'10 min',

date:'30 June 2026',

status:'Completed'

},

{

id:2,

filename:'Lecture.wav',

language:'Urdu',

duration:'45 min',

date:'29 June 2026',

status:'Completed'

},

{

id:3,

filename:'Interview.mp4',

language:'English',

duration:'18 min',

date:'28 June 2026',

status:'Processing'

}

])

</script>


<template>

<section class="page">

    <div class="top">

        <div>

            <h1>My Transcripts</h1>

            <p>
                View all generated transcripts.
            </p>

        </div>

        <input
            type="text"
            placeholder="Search transcript..."
        >

    </div>

    <div
        v-if="transcripts.length"
        class="grid"
    >

        <TranscriptCard

            v-for="item in transcripts"

            :key="item.id"

            :filename="item.filename"

            :language="item.language"

            :duration="item.duration"

            :date="item.date"

            :status="item.status"

        />

    </div>

    <EmptyState

        v-else

        title="No Transcripts"

        message="Upload an audio or video file to create your first transcript."

    />

</section>

</template>


<style scoped>

.page{

max-width:1200px;

margin:60px auto;

padding:20px;

}

.top{

display:flex;

justify-content:space-between;

align-items:center;

margin-bottom:40px;

gap:20px;

}

.top p{

margin-top:8px;

color:#6b7280;

}

input{

padding:12px;

width:280px;

border:1px solid #d1d5db;

border-radius:6px;

}

.grid{

display:grid;

grid-template-columns:repeat(auto-fit,minmax(320px,1fr));

gap:25px;

}

@media(max-width:768px){

.top{

flex-direction:column;

align-items:flex-start;

}

input{

width:100%;

}

}

</style>