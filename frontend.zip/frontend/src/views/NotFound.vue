<template>
  <div class="page">
    <h1>Not Found</h1>
    <p>The page you are looking for does not exist.</p>
  </div>
</template>

<style scoped>

.page{
    max-width:1100px;
    margin:40px auto;
    padding:20px;
}

.section-title{
    text-align:center;
    margin-bottom:30px;
}

.card{
    background:#fff;
    border:1px solid #ddd;
    border-radius:8px;
    padding:20px;
}

.button{
    background:#0d6efd;
    color:#fff;
    border:none;
    padding:10px 20px;
    border-radius:5px;
    cursor:pointer;
}

.button:hover{
    background:#0b5ed7;
}
</style>