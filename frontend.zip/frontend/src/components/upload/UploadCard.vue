<script setup>

import { ref } from 'vue'

const emit = defineEmits([
  'file-selected',
  'upload'
])

const fileInput = ref(null)

const selectedFile = ref(null)

function selectFile(event){

    selectedFile.value = event.target.files[0]

    emit('file-selected', selectedFile.value)

}

function uploadFile(){

    emit('upload')

}

</script>

<template>
  <div class="upload-card">

    <div class="upload-area">

      <div class="icon">📁</div>

      <h2>Upload Audio or Video</h2>

      <p>
        Supported formats: MP3, WAV, MP4, M4A
      </p>

      <input
        type="file"
        ref="fileInput"
        @change="selectFile"
        hidden
      />

      <button
        class="choose-btn"
        @click="fileInput.click()"
      >
        Choose File
      </button>

      <p
        v-if="selectedFile"
        class="filename"
      >
        Selected File:
        <strong>{{ selectedFile.name }}</strong>
      </p>

      <button
        class="upload-btn"
        :disabled="!selectedFile"
        @click="uploadFile"
      >
        Upload
      </button>

    </div>

  </div>
</template>



<style scoped>

.upload-card{

    max-width:700px;

    margin:auto;

}

.upload-area{

    background:white;

    border:2px dashed #2563eb;

    border-radius:12px;

    padding:50px;

    text-align:center;

}

.icon{

    font-size:60px;

    margin-bottom:20px;

}

h2{

    margin-bottom:10px;

    color:#1f2937;

}

p{

    color:#6b7280;

    margin-bottom:20px;

}

.choose-btn{

    background:#2563eb;

    color:white;

    border:none;

    padding:12px 24px;

    border-radius:8px;

    cursor:pointer;

}

.choose-btn:hover{

    background:#1d4ed8;

}

.filename{

    margin-top:20px;

    color:#111827;

}

.upload-btn{

    margin-top:25px;

    background:#16a34a;

    color:white;

    border:none;

    padding:12px 30px;

    border-radius:8px;

    cursor:pointer;

}

.upload-btn:disabled{

    background:#9ca3af;

    cursor:not-allowed;

}

</style>