<script setup>

defineProps({

icon:String,

title:String,

description:String

})

</script>

<template>

<div class="card">

    <div class="icon">

        {{ icon }}

    </div>

    <h3>

        {{ title }}

    </h3>

    <p>

        {{ description }}

    </p>

</div>

</template>



<style scoped>

.card{

    background:white;

    border-radius:10px;

    padding:30px;

    text-align:center;

    box-shadow:0 2px 10px rgba(0,0,0,.08);

    transition:.3s;

}

.card:hover{

    transform:translateY(-5px);

}

.icon{

    font-size:40px;

    margin-bottom:15px;

}

h3{

    margin-bottom:15px;

    color:#1f2937;

}

p{

    color:#6b7280;

    line-height:1.7;

}

</style>