<template>
  <section class="hero">

    <div class="hero-content">

      <h1>Transcripto AI</h1>

      <p>
        Convert your audio and video files into accurate text quickly and efficiently.
        Upload your recordings, manage transcripts, and export results with ease.
      </p>

      <RouterLink to="/upload" class="btn">
        Upload File
      </RouterLink>

    </div>

    <div class="hero-image">

      <img
        src="https://cdn-icons-png.flaticon.com/512/4727/4727424.png"
        alt="Transcription Illustration"
      >

    </div>

  </section>
</template>

<script setup>

</script>

<style scoped>

.hero{
    max-width:1200px;
    margin:60px auto;

    display:grid;
    grid-template-columns:1fr 1fr;
    gap:50px;
    align-items:center;

    padding:20px;
}

.hero-content h1{

    font-size:48px;
    color:#1f2937;
    margin-bottom:20px;

}

.hero-content p{

    color:#6b7280;
    line-height:1.8;
    font-size:18px;
    margin-bottom:30px;

}

.btn{

    display:inline-block;
    background:#2563eb;
    color:white;
    text-decoration:none;

    padding:14px 30px;

    border-radius:8px;

    transition:.2s;

}

.btn:hover{

    background:#1d4ed8;

}

.hero-image{

    text-align:center;

}

.hero-image img{

    width:100%;
    max-width:400px;

}

@media(max-width:768px){

.hero{

grid-template-columns:1fr;

text-align:center;

}

.hero-content h1{

font-size:36px;

}

}

</style>