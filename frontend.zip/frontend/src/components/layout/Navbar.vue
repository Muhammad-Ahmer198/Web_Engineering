<template>
  <nav class="navbar">
    <div class="container">

      <RouterLink to="/" class="logo">
        Transcripto AI
      </RouterLink>

      <ul class="nav-links">

        <li>
          <RouterLink to="/">Home</RouterLink>
        </li>

        <li>
          <RouterLink to="/about">About</RouterLink>
        </li>
        
        <li>
          <RouterLink to="/upload">Upload</RouterLink>
        </li>

        <li>
          <RouterLink to="/transcripts">Transcripts</RouterLink>
        </li>

        

        <li>
          <RouterLink to="/login">Login</RouterLink>
        </li>

        <li>
          <RouterLink to="/register" class="register-btn">
            Register
          </RouterLink>
        </li>

      </ul>

    </div>
  </nav>
</template>

<script setup>

</script>

<style scoped>

.navbar{
    background:#ffffff;
    border-bottom:1px solid #e5e7eb;
    position:sticky;
    top:0;
    z-index:1000;
}

.container{
    max-width:1200px;
    margin:auto;
    padding:16px 20px;

    display:flex;
    justify-content:space-between;
    align-items:center;
}

.logo{
    font-size:28px;
    font-weight:700;
    color:#2563eb;
    text-decoration:none;
}

.nav-links{
    display:flex;
    align-items:center;
    gap:20px;

    list-style:none;
    margin:0;
    padding:0;
}

.nav-links a{
    text-decoration:none;
    color:#374151;
    font-weight:500;
    transition:.2s;
}

.nav-links a:hover{
    color:#2563eb;
}

.router-link-active{
    color:#2563eb;
    font-weight:700;
}

.register-btn{
    background:#2563eb;
    color:white !important;
    padding:10px 18px;
    border-radius:6px;
}

.register-btn:hover{
    background:#1d4ed8;
}

@media(max-width:768px){

.container{
    flex-direction:column;
    gap:18px;
}

.nav-links{
    flex-wrap:wrap;
    justify-content:center;
}

.logo{
    font-size:24px;
}

}

</style>