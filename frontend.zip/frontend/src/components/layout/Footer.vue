<template>
  <footer class="footer">
    <div class="container">

      <div class="footer-grid">

        <!-- Project Info -->
        <div class="footer-section">
          <h2>Transcripto AI</h2>
          <p>
            A simple web application that converts audio and video into text.
            This frontend is developed using Vue 3 and Vite for the Semester Project.
          </p>
        </div>

        <!-- Quick Links -->
        <div class="footer-section">
          <h3>Quick Links</h3>

          <RouterLink to="/">Home</RouterLink>
          <RouterLink to="/upload">Upload</RouterLink>
          <RouterLink to="/transcripts">Transcripts</RouterLink>
          <RouterLink to="/about">About</RouterLink>
        </div>

        <!-- Technologies -->
        <div class="footer-section">
          <h3>Technologies</h3>

          <p>Vue 3</p>
          <p>Vite</p>
          <p>Vue Router</p>
          <p>Bootstrap</p>
        </div>

      </div>

      <hr>

      <div class="copyright">
        © 2026 Transcripto AI | University of Sialkot | BS Software Engineering
      </div>

    </div>
  </footer>
</template>

<script setup>

</script>

<style scoped>

.footer{
    background:#1f2937;
    color:white;
    margin-top:80px;
}

.container{
    max-width:1200px;
    margin:auto;
    padding:50px 20px 20px;
}

.footer-grid{
    display:grid;
    grid-template-columns:2fr 1fr 1fr;
    gap:40px;
}

.footer-section h2,
.footer-section h3{
    margin-bottom:15px;
}

.footer-section p{
    color:#d1d5db;
    line-height:1.7;
    margin:8px 0;
}

.footer-section a{
    display:block;
    color:#d1d5db;
    text-decoration:none;
    margin-bottom:10px;
    transition:.2s;
}

.footer-section a:hover{
    color:white;
}

hr{
    border:none;
    border-top:1px solid #4b5563;
    margin:30px 0 20px;
}

.copyright{
    text-align:center;
    color:#9ca3af;
    font-size:14px;
}

@media(max-width:768px){

.footer-grid{
    grid-template-columns:1fr;
    text-align:center;
}

}

</style>