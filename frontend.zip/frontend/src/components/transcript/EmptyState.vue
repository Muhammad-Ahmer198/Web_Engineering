<script setup>

defineProps({

title:String,

message:String

})

</script>

<template>

<div class="empty">

    <div class="icon">
        📄
    </div>

    <h2>
        {{ title }}
    </h2>

    <p>
        {{ message }}
    </p>

</div>

</template>



<style scoped>

.empty{

    background:white;

    border-radius:10px;

    padding:60px;

    text-align:center;

    box-shadow:0 2px 10px rgba(0,0,0,.08);

}

.icon{

    font-size:60px;

    margin-bottom:20px;

}

h2{

    margin-bottom:15px;

}

p{

    color:#6b7280;

}

</style>