<script setup>

import { computed } from 'vue'

const props = defineProps({

    filename:String,

    language:String,

    duration:String,

    date:String,

    status:String

})

const statusClass = computed(() => {

    if(props.status === 'Completed')
        return 'completed'

    if(props.status === 'Processing')
        return 'processing'

    return 'pending'

})

</script>

<template>
  <div class="card">

    <div class="header">

      <div>
        <h3>{{ filename }}</h3>
        <small>{{ language }}</small>
      </div>

      <span
        class="status"
        :class="statusClass"
      >
        {{ status }}
      </span>

    </div>

    <div class="details">

      <p>
        <strong>Duration:</strong>
        {{ duration }}
      </p>

      <p>
        <strong>Date:</strong>
        {{ date }}
      </p>

    </div>

    <div class="actions">

      <button class="view-btn">
        View
      </button>

      <button class="download-btn">
        Download
      </button>

    </div>

  </div>
</template>



<style scoped>

.card{

    background:white;

    border-radius:10px;

    padding:25px;

    box-shadow:0 2px 10px rgba(0,0,0,.08);

}

.header{

    display:flex;

    justify-content:space-between;

    align-items:center;

    margin-bottom:20px;

}

.header h3{

    margin-bottom:5px;

}

.header small{

    color:#6b7280;

}

.status{

    padding:8px 15px;

    border-radius:20px;

    color:white;

    font-size:14px;

}

.completed{

    background:#16a34a;

}

.processing{

    background:#f59e0b;

}

.pending{

    background:#6b7280;

}

.details{

    margin-bottom:20px;

}

.details p{

    margin-bottom:8px;

}

.actions{

    display:flex;

    gap:15px;

}

button{

    border:none;

    padding:10px 20px;

    border-radius:6px;

    cursor:pointer;

}

.view-btn{

    background:#2563eb;

    color:white;

}

.download-btn{

    background:#16a34a;

    color:white;

}

button:hover{

    opacity:.9;

}

</style>