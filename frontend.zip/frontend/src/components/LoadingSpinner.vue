<template>
  <div class="flex justify-center items-center py-10">
    <div class="w-10 h-10 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
  </div>
</template>